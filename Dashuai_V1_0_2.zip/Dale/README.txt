大帅·每日计划 V1.0.0
独立 applicationId: com.dashuai.todo
Java namespace 保持原值以兼容 JNI。
使用 DASHUAI_SIGNING，PKCS12 alias dashuai，格式 password:base64。
123 项独立 Java 测试通过；APK 和真机未验证。
