package com.dale.todo;
import java.util.Locale;
final class CategoryLogic {
 static final String[] NAMES={"科研工作","学习成长","生活日常","健康运动","约会","其他事项","会议事务"};
 static final int[] COLORS={0xff42699d,0xff75549a,0xff48754d,0xff986020,0xffa34b76,0xff656963,0xff28797b};
 static String key(String s){return s.trim().toLowerCase(Locale.ROOT).replaceAll("[\\s，。！？、,.!?]+", "");}
 static String normalize(String s){if(s.equals("运动健康"))return "健康运动";if(s.equals("家庭情感"))return "约会";return s;}
 static int index(String s){s=normalize(s);for(int i=0;i<NAMES.length;i++)if(NAMES[i].equals(s))return i;return -1;}
 static String infer(String s){if(s.matches("(?s).*(开会|会议|组会|例会|面试|会谈|研讨会).*"))return NAMES[6];if(s.matches("(?s).*(跑步|健身|运动|游泳|游个泳|瑜伽|散步|体检|锻炼|打球).*"))return NAMES[3];if(s.matches("(?s).*(约会|陪伴|家人|陪女友|陪男友|纪念日).*"))return NAMES[4];if(s.matches("(?s).*(阅读文献|读文献|学习|复习|背单词|阅读|读书|上课).*"))return NAMES[1];if(s.matches("(?s).*(实验|论文|科研|催化|数据|投稿|审稿|汇报|课题|核磁|NMR|nmr|质谱|色谱|电镜|光谱|送样|表征|测样).*"))return NAMES[0];if(s.matches("(?s).*(吃|喝|早餐|晚餐|午餐|买菜|购物|洗衣|打扫|睡觉|快递|做饭).*"))return NAMES[2];return NAMES[5];}
 static String select(String text,String suggested,String learned){if(!learned.isEmpty())return learned;String n=normalize(suggested);return index(n)>=0&&!n.equals(NAMES[5])?n:infer(text);}
}
