package com.dale.todo;
final class CommandIntent {
 static String normalize(String s){return s.trim().replaceAll("[\\s。！!？?]", "").replaceFirst("^(?:请帮我|麻烦帮我|帮我|请|麻烦)","").replaceFirst("^把","");}
 static boolean destructive(String v){return v.matches(".*(删除|删掉|删了|清空|取消|归档|都不要了).*" );}
 static boolean query(String v){return v.matches(".*(查看|查询|有哪些|还有什么|哪些没做|完成了什么|做完了什么).*" )&&!destructive(v);}
 static boolean bulk(String v){return v.matches(".*(删除|删掉|删了|清空|取消|归档|都不要了).*" )&&(v.matches(".*(所有|全部|都|清空).*" )||v.matches(".*(?:已完成|做完|完成的|未完成).*"));}
 static boolean unsafe(String v){return v.matches(".*(然后|但是|除了|不要删除|不要取消|不要清空|不要归档|别删|别取消|别归档|别清空|不删除|不取消|不归档|下周|下个月|大后天|如果|是否).*" );}
 static int state(String v){return v.matches(".*(未完成|没做完|没有完成|没完成).*" )?2:v.matches(".*(已完成|做完|完成的).*" )?1:0;}
 static String date(String v){return v.contains("明天")?"明天":v.contains("后天")?"后天":v.contains("今天")?"今天":"";}
}
