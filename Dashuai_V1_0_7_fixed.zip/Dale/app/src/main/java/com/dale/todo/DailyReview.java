package com.dale.todo;
import java.util.*;
final class DailyReview {
 int total,done,archived; final Map<String,Integer> categories=new LinkedHashMap<>(); final Map<String,List<String>> times=new TreeMap<>(); final List<String> pending=new ArrayList<>(); final Set<String> seen=new HashSet<>(); final List<String> duplicates=new ArrayList<>();
 void add(String name,String category,String time,boolean completed,boolean archive){total++;if(archive)archived++;if(completed){done++;categories.put(category,categories.getOrDefault(category,0)+1);return;}pending.add(name);if(!seen.add(name.trim()+"|"+time))duplicates.add(name);if(time.matches("(?:[01][0-9]|2[0-3]):[0-5][0-9]"))times.computeIfAbsent(time,k->new ArrayList<>()).add(name);}
 int percent(){return total==0?0:(int)Math.round(100.0*done/total);}
 String advice(){if(total==0)return "暂无任务记录。";return pending.isEmpty()?"所有任务均已完成。":"还有 "+pending.size()+" 项未完成，建议确认优先级后安排下一步。";}
 List<String> conflicts(){List<String> out=new ArrayList<>();for(Map.Entry<String,List<String>> e:times.entrySet())if(e.getValue().size()>1)out.add(e.getKey()+" · "+String.join("、",e.getValue()));return out;}
}
