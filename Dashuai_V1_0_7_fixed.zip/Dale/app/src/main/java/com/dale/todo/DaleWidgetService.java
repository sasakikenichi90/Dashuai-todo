package com.dale.todo;
import android.content.*;
import android.widget.*;
import org.json.*;
import java.util.*;
public class DaleWidgetService extends RemoteViewsService {
 public RemoteViewsFactory onGetViewFactory(Intent intent){return new Factory(getApplicationContext());}
 static class Factory implements RemoteViewsFactory {
  final Context c; JSONArray a=new JSONArray(); ArrayList<Integer> order=new ArrayList<>(); String day="";
  Factory(Context c){this.c=c;}
  public void onCreate(){}
  public void onDataSetChanged(){day=DaleWidget.day();a=new JSONArray();order.clear();try{JSONArray x=new JSONObject(DaleWidget.taskPrefs(c).getString("data","{}")).optJSONArray(day);if(x!=null)a=x;}catch(Exception ignored){}order.addAll(DaleWidgetService.order(a));}
  public int getCount(){return order.size();}
  public RemoteViews getViewAt(int position){if(position<0||position>=order.size())return null;return row(c,a,order.get(position),day);}
  public RemoteViews getLoadingView(){return null;} public int getViewTypeCount(){return 1;} public long getItemId(int p){return p;} public boolean hasStableIds(){return false;} public void onDestroy(){order.clear();}
 }
 static ArrayList<Integer> order(JSONArray a){ArrayList<Integer> result=new ArrayList<>();for(int i=0;i<a.length();i++)if(a.optJSONObject(i)!=null&&!a.optJSONObject(i).optBoolean("archived"))result.add(i);Collections.sort(result,(x,y)->Integer.compare(DaleWidget.rank(a.optJSONObject(x)),DaleWidget.rank(a.optJSONObject(y))));return result;}
 static RemoteViews row(Context c,JSONArray a,int index,String day){return render(c,a,index,day,true);}
 static RemoteViews directRow(Context c,JSONArray a,int index,String day){return render(c,a,index,day,false);}
 static RemoteViews render(Context c,JSONArray a,int index,String day,boolean collection){JSONObject o=a.optJSONObject(index);boolean done=o.optBoolean("done");RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.dale_widget_row);android.text.SpannableString t=new android.text.SpannableString(DaleWidget.label(o));if(done&&t.length()>0)t.setSpan(new android.text.style.StrikethroughSpan(),0,t.length(),33);v.setTextViewText(R.id.task_label,t);v.setTextColor(R.id.task_label,DaleWidget.priority(o)==1?0xffff0000:done?0xff8499b4:DaleWidget.color(o));v.setTextViewText(R.id.task_check,done?"☑":"☐");v.setTextColor(R.id.task_check,DaleWidget.priority(o)==1?0xffff0000:done?0xff3978d5:DaleWidget.color(o));v.setContentDescription(R.id.task_check,done?"恢复待办":"标记任务完成");if(collection)v.setOnClickFillInIntent(R.id.task_check,new Intent().putExtra("day",day).putExtra("index",index).putExtra("snapshot",o.toString()));return v;}
}
