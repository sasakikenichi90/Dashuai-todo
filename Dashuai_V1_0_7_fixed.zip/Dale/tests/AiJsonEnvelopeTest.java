package com.dale.todo;
public class AiJsonEnvelopeTest {
 public static void main(String[] args){String j="[{\"text\":\"开会\"}]"; int n=0;
 for(String x:new String[]{j,"```json\n"+j+"\n```","```JSON\r\n"+j+"\r\n```","```\n"+j+"\n```","\uFEFF"+j}){if(!j.equals(AiJsonEnvelope.unwrap(x)))throw new AssertionError(x);n++;}
 for(String x:new String[]{"```json\n"+j,"```json","说明"+j,"[{}","{}","","```python\n"+j+"\n```"}){try{AiJsonEnvelope.unwrap(x);throw new AssertionError(x);}catch(IllegalArgumentException e){n++;}}System.out.println(n+" tests passed");}
}
